
import React, { useState, useMemo } from 'react';
import { Project, CostRecord, ProjectStatus, Category } from '../types';
import { PlusIcon, TrashIcon, PencilIcon, LayersIcon, ReceiptIcon, ShareIcon } from './Icons';
import { useToast } from './Toast';
import ExcelExport from './ExcelExport';

interface ProjectListProps {
  projects: Project[];
  setProjects: React.Dispatch<React.SetStateAction<Project[]>>;
  costs: CostRecord[];
  setCosts: React.Dispatch<React.SetStateAction<CostRecord[]>>;
  categories: Category[]; 
}

type TimeFilter = 'all' | '30days' | '90days' | 'year';

const ProjectList: React.FC<ProjectListProps> = ({ projects, setProjects, costs, setCosts, categories }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newStatus, setNewStatus] = useState<ProjectStatus>('active');
  
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<{name: string, description: string, status: ProjectStatus}>({ 
    name: '', 
    description: '', 
    status: 'active' 
  });
  
  const [statusFilter, setStatusFilter] = useState<'all' | ProjectStatus>('all');
  const [timeFilter, setTimeFilter] = useState<TimeFilter>('all');
  
  const { showToast } = useToast();

  const handleAdd = () => {
    if (!newName.trim()) return;
    const newProject: Project = {
      id: crypto.randomUUID(),
      name: newName,
      description: newDesc,
      status: newStatus,
      createdAt: Date.now()
    };
    setProjects(prev => [...prev, newProject]);
    setNewName('');
    setNewDesc('');
    setNewStatus('active');
    setIsAdding(false);
    showToast('Projekt został pomyślnie utworzony!', 'success');
  };

  const handleDelete = (id: string) => {
    if (window.confirm("Czy na pewno chcesz usunąć ten projekt i wszystkie powiązane koszty?")) {
      setProjects(prev => prev.filter(p => p.id !== id));
      setCosts(prev => prev.filter(c => c.projectId !== id));
      showToast('Projekt i powiązane koszty zostały usunięte.', 'info');
    }
  };

  const startEditing = (project: Project) => {
    setEditingId(project.id);
    setEditForm({ 
      name: project.name, 
      description: project.description,
      status: project.status || 'active'
    });
  };

  const saveEdit = () => {
    if (!editForm.name.trim()) {
      showToast('Nazwa projektu nie może być pusta.', 'error');
      return;
    }
    setProjects(prev => prev.map(p => 
      p.id === editingId 
        ? { ...p, name: editForm.name, description: editForm.description, status: editForm.status } 
        : p
    ));
    setEditingId(null);
    showToast('Projekt został zaktualizowany.', 'success');
  };

  const handleShare = (projectName: string) => {
    const baseUrl = window.location.origin;
    const shareUrl = `${baseUrl}/project/${encodeURIComponent(projectName.replace(/\s+/g, '-').toLowerCase())}`;
    
    navigator.clipboard.writeText(shareUrl).then(() => {
      showToast('Link skopiowany do schowka!', 'success');
    }).catch(err => {
      console.error('Błąd kopiowania:', err);
      showToast('Nie udało się skopiować linku.', 'error');
    });
  };

  const filteredProjects = useMemo(() => {
    let result = [...projects];

    if (statusFilter !== 'all') {
      result = result.filter(p => p.status === statusFilter);
    }

    const now = Date.now();
    if (timeFilter === '30days') {
      result = result.filter(p => now - p.createdAt <= 30 * 24 * 60 * 60 * 1000);
    } else if (timeFilter === '90days') {
      result = result.filter(p => now - p.createdAt <= 90 * 24 * 60 * 60 * 1000);
    } else if (timeFilter === 'year') {
      const startOfYear = new Date(new Date().getFullYear(), 0, 1).getTime();
      result = result.filter(p => p.createdAt >= startOfYear);
    }

    return result.sort((a, b) => b.createdAt - a.createdAt);
  }, [projects, statusFilter, timeFilter]);

  const getProjectStats = (projectId: string) => {
    const projectCosts = costs.filter(c => c.projectId === projectId);
    const months: Record<string, number> = {};
    
    projectCosts.forEach(c => {
      const monthKey = c.date.substring(0, 7);
      months[monthKey] = (months[monthKey] || 0) + c.amount;
    });

    const sortedMonths = Object.keys(months).sort().reverse().slice(0, 3);
    const monthlyData = sortedMonths.map(m => ({ month: m, total: months[m] }));
    const maxMonthly = Math.max(...Object.values(months), 0);

    return { 
      monthlyData, 
      maxMonthly, 
      total: projectCosts.reduce((s, c) => s + c.amount, 0), 
      count: projectCosts.length 
    };
  };

  const getMonthName = (yearMonth: string) => {
    const [year, month] = yearMonth.split('-');
    const date = new Date(parseInt(year), parseInt(month) - 1);
    return date.toLocaleString('pl-PL', { month: 'short' });
  };

  const getStatusLabel = (status: ProjectStatus) => {
    switch(status) {
      case 'active': return { label: 'Aktywny', color: 'bg-emerald-100 text-emerald-700' };
      case 'completed': return { label: 'Zakończony', color: 'bg-blue-100 text-blue-700' };
      case 'on-hold': return { label: 'Wstrzymany', color: 'bg-orange-100 text-orange-700' };
      default: return { label: 'Aktywny', color: 'bg-slate-100 text-slate-700' };
    }
  };

  return (
    <div className="space-y-6 md:space-y-8 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 md:gap-6">
        <div>
          <h1 className="text-xl md:text-3xl font-black text-slate-900 tracking-tight leading-none">Twoje Projekty</h1>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-2">Zarządzanie operacyjne i budżetowe</p>
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white py-4 px-6 md:px-8 rounded-2xl flex items-center justify-center space-x-3 transition-all shadow-lg active:scale-95 font-black uppercase tracking-widest text-[10px] w-full md:w-auto"
        >
          <PlusIcon size={20} />
          <span>Utwórz Projekt</span>
        </button>
      </div>

      <div className="relative group">
        <div className="flex items-center space-x-2 overflow-x-auto pb-2 no-scrollbar scroll-smooth">
          <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest mr-2 whitespace-nowrap">Widok:</span>
          {['all', 'active', 'completed', 'on-hold'].map(id => (
            <button
              key={id}
              onClick={() => setStatusFilter(id as any)}
              className={`px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap border-2 ${
                statusFilter === id ? 'bg-slate-900 border-slate-900 text-white shadow-lg' : 'bg-white border-slate-100 text-slate-400 hover:border-slate-300'
              }`}
            >
              {id === 'all' ? 'Wszystkie' : id === 'active' ? 'Aktywne' : id === 'completed' ? 'Gotowe' : 'Stop'}
            </button>
          ))}
        </div>
      </div>

      {isAdding && (
        <div className="bg-white p-6 md:p-10 rounded-[2rem] border border-blue-100 shadow-2xl animate-in slide-in-from-top duration-500">
          <h2 className="text-xs font-black mb-8 text-slate-800 uppercase tracking-[0.2em]">Konfiguracja Nowego Projektu</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-8">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase ml-1">Nazwa *</label>
              <input 
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="Np. Budowa Domu"
                className="w-full px-5 py-4 border border-slate-100 rounded-2xl outline-none bg-slate-50 focus:bg-white focus:ring-4 focus:ring-blue-500/10 transition-all font-bold text-sm"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase ml-1">Opis</label>
              <input 
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                placeholder="Krótki opis celu"
                className="w-full px-5 py-4 border border-slate-100 rounded-2xl outline-none bg-slate-50 focus:bg-white focus:ring-4 focus:ring-blue-500/10 transition-all font-medium text-sm"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase ml-1">Status startowy</label>
              <select 
                value={newStatus}
                onChange={(e) => setNewStatus(e.target.value as ProjectStatus)}
                className="w-full px-5 py-4 border border-slate-100 rounded-2xl outline-none bg-slate-50 focus:bg-white focus:ring-4 focus:ring-blue-500/10 transition-all font-bold text-sm appearance-none"
              >
                <option value="active">Aktywny</option>
                <option value="completed">Zakończony</option>
                <option value="on-hold">Wstrzymany</option>
              </select>
            </div>
          </div>
          <div className="mt-10 flex flex-col sm:flex-row gap-4">
            <button onClick={handleAdd} className="flex-1 bg-blue-600 text-white px-8 py-5 rounded-2xl font-black uppercase tracking-widest text-[11px] shadow-xl shadow-blue-500/20 active:scale-[0.98] transition-all">Zapisz Projekt</button>
            <button onClick={() => setIsAdding(false)} className="flex-1 bg-slate-100 text-slate-500 px-8 py-5 rounded-2xl font-black uppercase tracking-widest text-[11px] active:scale-[0.98] transition-all">Anuluj</button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
        {filteredProjects.map(project => {
          const stats = getProjectStats(project.id);
          const isEditing = editingId === project.id;
          const statusInfo = getStatusLabel(project.status || 'active');
          
          return (
            <div key={project.id} className={`bg-white rounded-[2.5rem] shadow-sm border transition-all flex flex-col overflow-hidden group ${isEditing ? 'border-blue-400 ring-8 ring-blue-50' : 'border-slate-100 hover:shadow-2xl hover:shadow-slate-200/50 hover:-translate-y-1'}`}>
              {isEditing ? (
                <div className="p-8 space-y-5 animate-in fade-in duration-300 flex-1">
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Tryb Edycji</div>
                  <input 
                    value={editForm.name}
                    onChange={(e) => setEditForm({...editForm, name: e.target.value})}
                    className="w-full px-5 py-4 border border-slate-100 rounded-2xl text-sm font-bold bg-slate-50 focus:bg-white focus:ring-4 focus:ring-blue-500/10 transition-all"
                  />
                  <select 
                    value={editForm.status}
                    onChange={(e) => setEditForm({...editForm, status: e.target.value as ProjectStatus})}
                    className="w-full px-5 py-4 border border-slate-100 rounded-2xl text-sm font-bold bg-slate-50"
                  >
                    <option value="active">Aktywny</option>
                    <option value="completed">Zakończony</option>
                    <option value="on-hold">Wstrzymany</option>
                  </select>
                  <textarea 
                    value={editForm.description}
                    onChange={(e) => setEditForm({...editForm, description: e.target.value})}
                    rows={3}
                    className="w-full px-5 py-4 border border-slate-100 rounded-2xl text-xs bg-slate-50 resize-none font-medium focus:bg-white"
                  />
                  <div className="flex flex-col gap-3 pt-4">
                    <button onClick={saveEdit} className="w-full bg-blue-600 text-white font-black py-5 rounded-2xl uppercase tracking-widest text-[11px] shadow-lg">Zatwierdź</button>
                    <button onClick={() => setEditingId(null)} className="w-full bg-slate-50 text-slate-400 font-black py-5 rounded-2xl uppercase tracking-widest text-[11px]">Anuluj</button>
                  </div>
                </div>
              ) : (
                <>
                  <div className="p-6 md:p-8 flex-1 flex flex-col">
                    <div className="flex justify-between items-start mb-6">
                      <div className="flex-1 min-w-0 pr-4">
                        <div className="flex items-center space-x-2 mb-3">
                          <span className={`text-[9px] font-black uppercase px-2.5 py-1 rounded-lg tracking-widest ${statusInfo.color}`}>
                            {statusInfo.label}
                          </span>
                        </div>
                        <h3 className="text-xl md:text-2xl font-black text-slate-900 leading-tight mb-2 truncate group-hover:text-blue-600 transition-colors">{project.name}</h3>
                        <p className="text-slate-500 text-xs line-clamp-2 font-medium leading-relaxed">{project.description || 'Brak dodatkowego opisu projektu.'}</p>
                      </div>

                      {/* Desktop Side Actions - hidden on mobile */}
                      <div className="hidden md:flex flex-col items-center bg-slate-50 rounded-2xl p-1 border border-slate-100">
                        <button onClick={() => handleShare(project.name)} className="p-3 text-slate-400 hover:text-emerald-500 rounded-xl active:scale-90 transition-all"><ShareIcon size={18} /></button>
                        <ExcelExport projects={projects} categories={categories} costs={costs} projectId={project.id} variant="icon" />
                        <button onClick={() => startEditing(project)} className="p-3 text-slate-400 hover:text-blue-500 rounded-xl active:scale-90 transition-all"><PencilIcon size={18} /></button>
                        <button onClick={() => handleDelete(project.id)} className="p-3 text-slate-400 hover:text-red-500 rounded-xl active:scale-90 transition-all"><TrashIcon size={18} /></button>
                      </div>
                    </div>

                    {/* Mobile Quick Actions - only visible on small screens */}
                    <div className="md:hidden flex items-center justify-between gap-2 mb-6 p-2 bg-slate-50 rounded-2xl border border-slate-100">
                        <button onClick={() => handleShare(project.name)} className="flex-1 flex justify-center p-3 text-slate-500 bg-white rounded-xl shadow-sm"><ShareIcon size={18} /></button>
                        <ExcelExport projects={projects} categories={categories} costs={costs} projectId={project.id} variant="icon" />
                        <button onClick={() => startEditing(project)} className="flex-1 flex justify-center p-3 text-slate-500 bg-white rounded-xl shadow-sm"><PencilIcon size={18} /></button>
                        <button onClick={() => handleDelete(project.id)} className="flex-1 flex justify-center p-3 text-red-400 bg-white rounded-xl shadow-sm"><TrashIcon size={18} /></button>
                    </div>

                    <div className="bg-slate-50/50 p-5 md:p-6 rounded-[2rem] border border-slate-100 mt-auto">
                       <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-4 flex items-center">
                         <ReceiptIcon size={12} className="mr-3 text-blue-500" /> Wydatki ostatnie
                       </p>
                       <div className="space-y-4">
                         {stats.monthlyData.length > 0 ? stats.monthlyData.map((d, i) => (
                           <div key={i} className="flex flex-col space-y-1.5">
                             <div className="flex justify-between text-[10px] font-black uppercase tracking-tight">
                               <span className="text-slate-400">{getMonthName(d.month)}</span>
                               <span className="text-slate-900">{d.total.toLocaleString('pl-PL')} PLN</span>
                             </div>
                             <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                               <div 
                                 className="h-full bg-blue-500 rounded-full transition-all duration-1000 ease-out" 
                                 style={{ width: `${(d.total / (stats.maxMonthly || 1)) * 100}%` }} 
                               />
                             </div>
                           </div>
                         )) : (
                           <p className="text-[10px] text-slate-300 font-bold uppercase italic text-center py-2">Brak danych</p>
                         )}
                       </div>
                    </div>
                  </div>

                  <div className="bg-slate-900 p-6 md:p-8 mt-auto flex flex-col sm:flex-row sm:items-end justify-between gap-4">
                    <div>
                      <p className="text-[9px] font-black text-slate-500 uppercase tracking-[0.2em] mb-1.5">Koszt całkowity</p>
                      <p className="text-2xl md:text-3xl font-black text-white leading-none tracking-tight">
                        {stats.total.toLocaleString('pl-PL')} <span className="text-[11px] font-bold text-blue-400 ml-1">PLN</span>
                      </p>
                    </div>
                    <div className="sm:text-right">
                      <div className="inline-flex bg-white/10 px-4 py-2 rounded-xl border border-white/10 backdrop-blur-md">
                         <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest">{stats.count} rekordów</p>
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ProjectList;
