
import { Category } from './types';

export const DEFAULT_CATEGORIES: Category[] = [
  { id: 'cat-1', name: 'Paliwo', isDefault: true },
  { id: 'cat-2', name: 'Gaz', isDefault: true },
  { id: 'cat-3', name: 'Naprawy pomieszczeń', isDefault: true },
  { id: 'cat-4', name: 'Naprawy samochodów', isDefault: true },
  { id: 'cat-5', name: 'Koszty najmu (czynsz)', isDefault: true },
  { id: 'cat-6', name: 'Wydarzenia nieoczekiwane', isDefault: true },
];

export const APP_STORAGE_KEY = 'project_budget_pro_data';
