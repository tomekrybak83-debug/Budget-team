
import { Project, CostRecord, Category, User } from './types';
import { APP_STORAGE_KEY } from './constants';

// Symulacja opóźnienia serwera (np. 500ms)
const LATENCY = 600;

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const api = {
  // Pobieranie wszystkich danych (Initial Sync)
  async fetchAllData(userId: string) {
    await delay(LATENCY);
    const key = `${APP_STORAGE_KEY}_${userId}`;
    const saved = localStorage.getItem(key);
    if (!saved) return { projects: [], costs: [], categories: [] };
    return JSON.parse(saved);
  },

  // Zapisywanie stanu (Full Sync)
  async syncAll(userId: string, data: { projects: Project[], costs: CostRecord[], categories: Category[] }) {
    await delay(LATENCY);
    const key = `${APP_STORAGE_KEY}_${userId}`;
    localStorage.setItem(key, JSON.stringify(data));
    return { success: true, timestamp: Date.now() };
  },

  // Pojedyncze operacje (przyszłościowe API REST)
  async saveProject(userId: string, project: Project) {
    await delay(LATENCY / 2);
    // Logika aktualizacji w mock-db
    return { success: true };
  },

  async deleteProject(userId: string, projectId: string) {
    await delay(LATENCY / 2);
    return { success: true };
  }
};
