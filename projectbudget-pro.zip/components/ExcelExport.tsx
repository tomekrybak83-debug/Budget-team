
import React from 'react';
import * as XLSX from 'xlsx';
import { Project, Category, CostRecord } from '../types';
import { DownloadIcon } from './Icons';

interface ExcelExportProps {
  projects: Project[];
  categories: Category[];
  costs: CostRecord[];
  projectId?: string; // Opcjonalny filtr projektu
  variant?: 'full' | 'icon'; // Wariant wyglądu
}

const ExcelExport: React.FC<ExcelExportProps> = ({ 
  projects, 
  categories, 
  costs, 
  projectId, 
  variant = 'full' 
}) => {
  const handleExport = (e: React.MouseEvent) => {
    e.stopPropagation(); // Zapobiega interakcjom z kartą projektu
    
    let filteredCosts = costs;
    let selectedProject: Project | undefined;

    if (projectId) {
      selectedProject = projects.find(p => p.id === projectId);
      filteredCosts = costs.filter(c => c.projectId === projectId);
    }

    if (filteredCosts.length === 0) {
      alert("Brak danych do eksportu dla wybranego zakresu.");
      return;
    }

    // Przygotowanie danych do arkusza głównego
    const masterData = filteredCosts.map(cost => {
      const proj = projects.find(p => p.id === cost.projectId);
      const cat = categories.find(c => c.id === cost.categoryId);
      return {
        'Data': cost.date,
        'Projekt': proj?.name || 'Nieznany',
        'Kategoria': cat?.name || 'Inne',
        'Kwota (PLN)': cost.amount,
        'Opis': cost.description
      };
    });

    const wb = XLSX.utils.book_new();

    // 1. Arkusz wszystkich rekordów (przefiltrowany)
    const wsAll = XLSX.utils.json_to_sheet(masterData);
    const sheetName = selectedProject ? `Koszty - ${selectedProject.name.substring(0, 20)}` : "Wszystkie Wydatki";
    XLSX.utils.book_append_sheet(wb, wsAll, sheetName);

    // 2. Podsumowanie (jeśli eksport globalny, dodaj statystyki projektów)
    if (!projectId) {
      const projectSummary = projects.map(p => ({
        'Nazwa Projektu': p.name,
        'Suma Wydatków': costs.filter(c => c.projectId === p.id).reduce((s, c) => s + c.amount, 0),
        'Liczba Wpisów': costs.filter(c => c.projectId === p.id).length
      })).filter(p => p['Liczba Wpisów'] > 0);
      
      const wsProj = XLSX.utils.json_to_sheet(projectSummary);
      XLSX.utils.book_append_sheet(wb, wsProj, "Podsumowanie Projektów");
    }

    // 3. Generowanie pliku
    const dateStr = new Date().toISOString().split('T')[0];
    const fileName = selectedProject 
      ? `Raport_${selectedProject.name.replace(/\s+/g, '_')}_${dateStr}.xlsx` 
      : `Raport_Budzetowy_Globalny_${dateStr}.xlsx`;
      
    XLSX.writeFile(wb, fileName);
  };

  if (variant === 'icon') {
    return (
      <button 
        onClick={handleExport}
        className="p-3.5 text-slate-400 hover:text-blue-600 hover:bg-white rounded-xl transition-all active:scale-90"
        title="Eksportuj projekt do Excel"
      >
        <DownloadIcon size={20} />
      </button>
    );
  }

  return (
    <button 
      onClick={handleExport}
      className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-all shadow-sm font-bold text-sm"
    >
      <DownloadIcon size={18} />
      <span className="hidden sm:inline">Eksportuj do Excel</span>
      <span className="sm:hidden">Eksport</span>
    </button>
  );
};

export default ExcelExport;
