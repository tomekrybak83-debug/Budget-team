
import React, { useState, useRef, useEffect } from 'react';
import { Category, Project, CostRecord, User } from '../types';
import { PlusIcon, TrashIcon, DownloadIcon, UploadIcon, LogoIcon, ShareIcon, PencilIcon, ReceiptIcon } from './Icons';
import { useToast } from './Toast';

interface SettingsProps {
  categories: Category[];
  projects: Project[];
  costs: CostRecord[];
  setCategories: React.Dispatch<React.SetStateAction<Category[]>>;
  setProjects: React.Dispatch<React.SetStateAction<Project[]>>;
  setCosts: React.Dispatch<React.SetStateAction<CostRecord[]>>;
  currentUser: User;
  setCurrentUser: React.Dispatch<React.SetStateAction<User | null>>;
  syncStatus: 'idle' | 'syncing' | 'synced' | 'error';
  googleAccessToken: string | null;
  setGoogleAccessToken: (token: string | null) => void;
}

const Settings: React.FC<SettingsProps> = ({ 
  categories, projects, costs, setCategories, setProjects, setCosts, 
  currentUser, setCurrentUser, syncStatus, googleAccessToken, setGoogleAccessToken 
}) => {
  const [newCatName, setNewCatName] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);
  const { showToast } = useToast();
  const tokenClientRef = useRef<any>(null);

  useEffect(() => {
    const initGIS = () => {
      const google = (window as any).google;
      if (google?.accounts?.oauth2) {
        tokenClientRef.current = google.accounts.oauth2.initTokenClient({
          client_id: '714424361545-placeholder.apps.googleusercontent.com',
          scope: 'https://www.googleapis.com/auth/drive.file',
          callback: (response: any) => {
            if (response.access_token) {
              setGoogleAccessToken(response.access_token);
              const updatedUser = { ...currentUser, googleDriveEnabled: true };
              setCurrentUser(updatedUser);
              showToast('Połączono z Google Drive!', 'success');
            } else if (response.error) {
              showToast('Błąd autoryzacji Google.', 'error');
            }
          },
        });
      }
    };

    const timer = setInterval(() => {
      if ((window as any).google?.accounts?.oauth2) {
        initGIS();
        clearInterval(timer);
      }
    }, 500);

    return () => clearInterval(timer);
  }, [currentUser, setCurrentUser, setGoogleAccessToken, showToast]);

  const handleGoogleConnect = () => {
    if (tokenClientRef.current) {
      tokenClientRef.current.requestAccessToken({ prompt: 'consent' });
    } else {
      showToast('Usługi Google nie są jeszcze gotowe. Spróbuj za chwilę.', 'info');
    }
  };

  const handleAddCategory = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!newCatName.trim()) return;
    
    if (categories.some(c => c.name.toLowerCase() === newCatName.trim().toLowerCase())) {
      showToast('Taka kategoria już istnieje.', 'error');
      return;
    }

    const newCat: Category = {
      id: crypto.randomUUID(),
      name: newCatName.trim(),
      isDefault: false
    };
    setCategories(prev => [...prev, newCat]);
    setNewCatName('');
    showToast(`Dodano kategorię: ${newCat.name}`, 'success');
  };

  const handleDeleteCategory = (id: string) => {
    const cat = categories.find(c => c.id === id);
    if (cat?.isDefault) {
      showToast("Kategorie systemowe są chronione.", 'error');
      return;
    }

    const isInUse = costs.some(c => c.categoryId === id);
    if (isInUse) {
      if (!confirm("Ta kategoria jest używana w istniejących wpisach. Usunięcie jej może wpłynąć na raporty. Kontynuować?")) {
        return;
      }
    }

    setCategories(prev => prev.filter(c => c.id !== id));
    showToast("Kategoria usunięta.", 'info');
  };

  const exportData = () => {
    const data = { projects, categories, costs, customLogoUrl: currentUser.customLogoUrl, exportedAt: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `BudgetPro_Data_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
    showToast("Eksport zakończony.", 'success');
  };

  const importData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const json = JSON.parse(e.target?.result as string);
        if (confirm("Import nadpisze wszystkie obecne dane projektowe. Kontynuować?")) {
          setProjects(json.projects || []);
          setCategories(json.categories || []);
          setCosts(json.costs || []);
          if (json.customLogoUrl) {
            setCurrentUser(prev => prev ? { ...prev, customLogoUrl: json.customLogoUrl } : null);
          }
          showToast("Dane zaimportowane pomyślnie!", 'success');
        }
      } catch (err) { showToast("Błędny format pliku .json", 'error'); }
    };
    reader.readAsText(file);
  };

  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (file.size > 1.5 * 1024 * 1024) {
      showToast("Logo zbyt ciężkie (max 1.5MB).", "error");
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const base64 = e.target?.result as string;
      setCurrentUser(prev => prev ? { ...prev, customLogoUrl: base64 } : null);
      showToast("Logo zostało zmienione.", "success");
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-10 max-w-4xl pb-20 md:pb-12 animate-in fade-in duration-500">
      <header>
        <h1 className="text-3xl font-black text-slate-900 tracking-tight leading-none">Centrum Zarządzania</h1>
        <p className="text-slate-500 mt-3 font-medium text-sm md:text-base">Personalizacja platformy i bezpieczeństwo Twoich danych operacyjnych.</p>
      </header>

      {/* Branding Section */}
      <section className="bg-white p-6 md:p-8 rounded-[2rem] shadow-sm border border-slate-100 overflow-hidden relative">
        <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-50 rounded-bl-full -z-0 opacity-50"></div>
        <h2 className="text-lg font-black mb-8 flex items-center relative z-10 text-slate-900">
          <span className="w-8 h-8 bg-indigo-600 text-white rounded-xl flex items-center justify-center mr-4 text-[10px] font-black uppercase tracking-tighter">01</span>
          Twoja Marka
        </h2>
        
        <div className="flex flex-col md:flex-row items-center gap-8 md:gap-12 relative z-10">
          <div className="relative">
            <div className="w-32 h-32 md:w-40 md:h-40 bg-slate-50 rounded-[2rem] border-2 border-dashed border-slate-200 flex items-center justify-center overflow-hidden transition-all hover:border-blue-400 group shadow-inner">
               <LogoIcon customUrl={currentUser.customLogoUrl} size={80} className="text-slate-300 transition-transform group-hover:scale-110" />
            </div>
            <button 
              onClick={() => logoInputRef.current?.click()}
              className="absolute -bottom-2 -right-2 bg-slate-900 text-white p-3 rounded-xl shadow-xl hover:bg-blue-600 transition-all active:scale-90 border-4 border-white"
            >
              <PencilIcon size={16} />
            </button>
            <input type="file" accept="image/*" className="hidden" ref={logoInputRef} onChange={handleLogoUpload} />
          </div>

          <div className="flex-1 space-y-4 text-center md:text-left">
            <div>
              <h3 className="font-black text-slate-900 text-lg tracking-tight">Logo Systemu</h3>
              <p className="text-slate-500 text-xs mt-2 max-w-md leading-relaxed">
                Spersonalizuj aplikację własnym logo. Będzie ono widoczne na pasku bocznym oraz na wszystkich eksportowanych dokumentach.
              </p>
            </div>
            <div className="flex flex-wrap justify-center md:justify-start gap-3 pt-2">
              <button 
                onClick={() => logoInputRef.current?.click()}
                className="bg-slate-900 text-white px-6 py-3 rounded-xl hover:bg-slate-800 text-[10px] font-black uppercase tracking-widest transition-all shadow-lg"
              >
                Zmień obraz
              </button>
              {currentUser.customLogoUrl && (
                <button 
                  onClick={() => setCurrentUser(prev => prev ? { ...prev, customLogoUrl: undefined } : null)}
                  className="bg-red-50 text-red-600 px-6 py-3 rounded-xl hover:bg-red-100 text-[10px] font-black uppercase tracking-widest transition-all"
                >
                  Przywróć domyślne
                </button>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Categories Management Section */}
      <section className="bg-white p-6 md:p-8 rounded-[2rem] shadow-sm border border-slate-100 overflow-hidden relative">
        <div className="absolute top-0 right-0 w-32 h-32 bg-orange-50 rounded-bl-full -z-0 opacity-50"></div>
        <h2 className="text-lg font-black mb-8 flex items-center relative z-10 text-slate-900">
          <span className="w-8 h-8 bg-orange-500 text-white rounded-xl flex items-center justify-center mr-4 text-[10px] font-black uppercase tracking-tighter">02</span>
          Kategorie Kosztów
        </h2>
        
        <div className="relative z-10 space-y-6">
          <form onSubmit={handleAddCategory} className="flex gap-2">
            <input 
              type="text"
              placeholder="Nazwa nowej kategorii..."
              className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs font-bold outline-none focus:ring-2 focus:ring-orange-500 transition-all"
              value={newCatName}
              onChange={(e) => setNewCatName(e.target.value)}
            />
            <button 
              type="submit"
              className="bg-orange-500 hover:bg-orange-600 text-white px-5 py-3 rounded-xl shadow-lg shadow-orange-500/20 active:scale-95 transition-all"
            >
              <PlusIcon size={18} />
            </button>
          </form>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 max-h-[400px] overflow-y-auto pr-2 no-scrollbar">
            {categories.map((cat) => (
              <div 
                key={cat.id} 
                className="group bg-slate-50 border border-slate-100 p-4 rounded-2xl flex justify-between items-center transition-all hover:bg-white hover:shadow-md"
              >
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-lg ${cat.isDefault ? 'bg-orange-100 text-orange-600' : 'bg-slate-200 text-slate-500'}`}>
                    <ReceiptIcon size={14} />
                  </div>
                  <span className="text-xs font-black text-slate-700 truncate max-w-[120px]">{cat.name}</span>
                </div>
                {cat.isDefault ? (
                  <div className="text-slate-300" title="Kategoria systemowa">
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                    </svg>
                  </div>
                ) : (
                  <button 
                    onClick={() => handleDeleteCategory(cat.id)}
                    className="text-slate-300 hover:text-red-500 transition-colors"
                  >
                    <TrashIcon size={14} />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Google Sync Section */}
      <section className="bg-white p-6 md:p-8 rounded-[2rem] shadow-sm border border-slate-100 overflow-hidden relative">
        <div className="absolute top-0 right-0 w-32 h-32 bg-blue-50 rounded-bl-full -z-0 opacity-50"></div>
        <div className="flex justify-between items-start mb-8 relative z-10">
          <div>
            <h2 className="text-lg font-black flex items-center text-slate-900">
              <span className="w-8 h-8 bg-blue-600 text-white rounded-xl flex items-center justify-center mr-4 text-[10px] font-black uppercase tracking-tighter">03</span>
              Google Cloud Sync
            </h2>
            <p className="text-slate-500 text-xs mt-2 font-medium leading-relaxed max-w-sm">
              Pełna synchronizacja z Google Drive zapewnia bezpieczeństwo i dostęp do budżetu na dowolnym urządzeniu.
            </p>
          </div>
          <span className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest shadow-sm ${
            syncStatus === 'synced' ? 'bg-emerald-100 text-emerald-700' : 
            syncStatus === 'syncing' ? 'bg-blue-100 text-blue-700 animate-pulse' : 
            syncStatus === 'error' ? 'bg-red-100 text-red-600' : 'bg-slate-100 text-slate-500'
          }`}>
            {syncStatus === 'synced' ? 'Gotowy' : syncStatus === 'syncing' ? 'Przesyłanie' : 'Offline'}
          </span>
        </div>

        {!currentUser.googleDriveEnabled ? (
          <button 
            onClick={handleGoogleConnect}
            className="w-full sm:w-auto bg-white border border-slate-200 text-slate-800 px-8 py-4 rounded-2xl hover:border-blue-500 hover:text-blue-600 flex items-center justify-center space-x-4 font-black transition-all active:scale-95 shadow-sm group"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
            <span className="uppercase text-[10px] tracking-[0.15em]">Połącz z Google Drive</span>
          </button>
        ) : (
          <div className="bg-slate-50 rounded-2xl p-6 flex flex-col sm:flex-row justify-between items-center gap-6 border border-slate-100">
            <div className="flex items-center space-x-5">
              <div className="bg-emerald-500 text-white p-3 rounded-xl shadow-lg shadow-emerald-200">
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <div>
                <p className="font-black text-slate-900 text-base leading-tight">Status: Aktywny</p>
                <p className="text-[10px] text-slate-500 font-black uppercase mt-1 tracking-widest">
                  Auto-Backup włączony
                </p>
              </div>
            </div>
            <button 
              onClick={() => {
                setCurrentUser(prev => prev ? { ...prev, googleDriveEnabled: false } : null);
                setGoogleAccessToken(null);
                showToast('Synchronizacja wyłączona.', 'info');
              }}
              className="text-[9px] font-black uppercase tracking-widest text-red-500 bg-white border border-red-50 px-5 py-2.5 rounded-xl hover:bg-red-50 transition-all"
            >
              Rozłącz chmurę
            </button>
          </div>
        )}
      </section>

      {/* Export/Import Section */}
      <section className="bg-white p-6 md:p-8 rounded-[2rem] shadow-sm border border-slate-100">
        <h2 className="text-lg font-black mb-8 flex items-center text-slate-900">
          <span className="w-8 h-8 bg-emerald-600 text-white rounded-xl flex items-center justify-center mr-4 text-[10px] font-black uppercase tracking-tighter">04</span>
          Eksport i Import
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 group transition-all hover:bg-white hover:shadow-xl hover:shadow-slate-200/50">
            <h3 className="font-black text-slate-900 mb-2 text-sm">Pobierz kopię lokalną</h3>
            <p className="text-[10px] text-slate-500 mb-6 font-medium leading-relaxed">Pełna struktura danych w formacie JSON do ręcznego przechowywania.</p>
            <button 
              onClick={exportData}
              className="w-full bg-slate-900 text-white py-4 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center space-x-3 transition-all active:scale-[0.98]"
            >
              <DownloadIcon size={16} />
              <span>Eksportuj (.json)</span>
            </button>
          </div>
          <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 group transition-all hover:bg-white hover:shadow-xl hover:shadow-slate-200/50">
            <h3 className="font-black text-slate-900 mb-2 text-sm">Przywróć stan systemu</h3>
            <p className="text-[10px] text-slate-500 mb-6 font-medium leading-relaxed">Wgraj plik kopii zapasowej, aby przywrócić wszystkie dane.</p>
            <input type="file" accept=".json" className="hidden" ref={fileInputRef} onChange={importData} />
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="w-full bg-emerald-600 text-white py-4 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center space-x-3 shadow-lg shadow-emerald-200 transition-all active:scale-[0.98]"
            >
              <UploadIcon size={16} />
              <span>Importuj plik</span>
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Settings;
