
import React, { useState, useMemo } from 'react';
import { Project, Category, CostRecord } from '../types';
import { PlusIcon, TrashIcon, PencilIcon, ReceiptIcon } from './Icons';
import { useToast } from './Toast';

interface CostTrackerProps {
  projects: Project[];
  categories: Category[];
  costs: CostRecord[];
  setCosts: React.Dispatch<React.SetStateAction<CostRecord[]>>;
}

type ViewMode = 'list' | 'calendar';

const CostTracker: React.FC<CostTrackerProps> = ({ projects, categories, costs, setCosts }) => {
  const [viewMode, setViewMode] = useState<ViewMode>('list');
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [quickEditingId, setQuickEditingId] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const { showToast } = useToast();
  
  // Calendar State
  const [currentCalendarDate, setCurrentCalendarDate] = useState(new Date());

  const [filterProject, setFilterProject] = useState('');
  const [filterCategory, setFilterCategory] = useState('');
  const [filterStartDate, setFilterStartDate] = useState('');
  const [filterEndDate, setFilterEndDate] = useState('');

  const [formData, setFormData] = useState({
    projectId: '',
    categoryId: '',
    amount: '',
    date: new Date().toISOString().split('T')[0],
    description: ''
  });

  const [editFormData, setEditFormData] = useState<Partial<CostRecord>>({});
  const [quickEditData, setQuickEditData] = useState<{ amount: number; date: string }>({ amount: 0, date: '' });

  const filteredCosts = useMemo(() => {
    let list = [...costs].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    
    if (filterProject) {
      list = list.filter(c => c.projectId === filterProject);
    }
    
    if (filterCategory) {
      list = list.filter(c => c.categoryId === filterCategory);
    }

    if (filterStartDate) {
      list = list.filter(c => c.date >= filterStartDate);
    }

    if (filterEndDate) {
      list = list.filter(c => c.date <= filterEndDate);
    }

    return list;
  }, [costs, filterProject, filterCategory, filterStartDate, filterEndDate]);

  const resetFilters = () => {
    setFilterProject('');
    setFilterCategory('');
    setFilterStartDate('');
    setFilterEndDate('');
    showToast('Filtry zostały wyczyszczone.', 'info');
  };

  const handleAdd = () => {
    if (!formData.projectId || !formData.categoryId || !formData.amount) {
      showToast("Proszę wypełnić wymagane pola (Projekt, Kategoria, Kwota)", "error");
      return;
    }

    const newRecord: CostRecord = {
      id: crypto.randomUUID(),
      projectId: formData.projectId,
      categoryId: formData.categoryId,
      amount: parseFloat(formData.amount),
      date: formData.date,
      description: formData.description
    };

    setCosts(prev => [newRecord, ...prev]);
    setIsAdding(false);
    setFormData({ ...formData, amount: '', description: '' });
    showToast('Wydatek został pomyślnie zarejestrowany.', 'success');
  };

  const startEditing = (cost: CostRecord) => {
    setEditingId(cost.id);
    setEditFormData({ ...cost });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const startQuickEdit = (cost: CostRecord, e: React.MouseEvent) => {
    e.stopPropagation();
    setQuickEditingId(cost.id);
    setQuickEditData({ amount: cost.amount, date: cost.date });
  };

  const handleSaveQuickEdit = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (isNaN(quickEditData.amount)) {
      showToast('Wprowadź poprawną kwotę.', 'error');
      return;
    }
    setCosts(prev => prev.map(c => 
      c.id === id ? { ...c, amount: quickEditData.amount, date: quickEditData.date } : c
    ));
    setQuickEditingId(null);
    showToast('Zaktualizowano (Quick Edit).', 'success');
  };

  const handleSaveEdit = () => {
    if (!editFormData.projectId || !editFormData.categoryId || editFormData.amount === undefined) {
      showToast('Wypełnij wszystkie wymagane pola.', 'error');
      return;
    }

    setCosts(prev => prev.map(c => 
      c.id === editingId ? (editFormData as CostRecord) : c
    ));
    setEditingId(null);
    showToast('Wpis kosztowy został zaktualizowany.', 'success');
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm("Usunąć ten wpis kosztowy?")) {
      setCosts(prev => prev.filter(c => c.id !== id));
      showToast('Wpis kosztowy został usunięty.', 'info');
    }
  };

  const toggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  // Calendar Helpers
  const daysInMonth = (year: number, month: number) => new Date(year, month + 1, 0).getDate();
  const firstDayOfMonth = (year: number, month: number) => {
    const day = new Date(year, month, 1).getDay();
    return day === 0 ? 6 : day - 1; // Adjust for Mon-Sun week
  };

  const calendarDays = useMemo(() => {
    const year = currentCalendarDate.getFullYear();
    const month = currentCalendarDate.getMonth();
    const totalDays = daysInMonth(year, month);
    const startOffset = firstDayOfMonth(year, month);
    
    const days = [];
    // Previous month padding
    for (let i = 0; i < startOffset; i++) {
      days.push({ type: 'empty' });
    }
    // Current month days
    for (let i = 1; i <= totalDays; i++) {
      const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
      const dayCosts = costs.filter(c => c.date === dateStr);
      const dayTotal = dayCosts.reduce((sum, c) => sum + c.amount, 0);
      days.push({ 
        type: 'day', 
        date: i, 
        fullDate: dateStr, 
        total: dayTotal,
        hasCosts: dayCosts.length > 0 
      });
    }
    return days;
  }, [currentCalendarDate, costs]);

  const changeMonth = (offset: number) => {
    const newDate = new Date(currentCalendarDate);
    newDate.setMonth(newDate.getMonth() + offset);
    setCurrentCalendarDate(newDate);
  };

  const hasActiveFilters = filterProject || filterCategory || filterStartDate || filterEndDate;

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col gap-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight leading-none">Ewidencja Kosztów</h1>
            <p className="text-[9px] md:text-[10px] font-black text-slate-400 uppercase tracking-widest mt-2">Dziennik operacji finansowych</p>
          </div>
          <div className="flex items-center space-x-2 w-full sm:w-auto">
            <div className="bg-slate-100 p-1 rounded-xl flex">
              <button 
                onClick={() => setViewMode('list')}
                className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${viewMode === 'list' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-400 hover:text-slate-600'}`}
              >
                Lista
              </button>
              <button 
                onClick={() => setViewMode('calendar')}
                className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${viewMode === 'calendar' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-400 hover:text-slate-600'}`}
              >
                Kalendarz
              </button>
            </div>
            <button 
              onClick={() => setIsAdding(true)}
              className="flex-1 sm:flex-none bg-blue-600 hover:bg-blue-700 text-white px-4 md:px-5 py-3 rounded-xl md:rounded-2xl flex items-center justify-center space-x-2 transition-all shadow-lg active:scale-95 font-black uppercase text-[10px] tracking-widest"
            >
              <PlusIcon size={18} />
              <span className="hidden sm:inline">Nowy Rekord</span>
              <span className="sm:hidden">Dodaj</span>
            </button>
          </div>
        </div>

        {viewMode === 'list' && (
          <div className="bg-white p-1 rounded-2xl md:rounded-3xl shadow-sm border border-slate-100">
            <button 
              onClick={() => setShowFilters(!showFilters)}
              className="lg:hidden w-full px-4 py-3 flex justify-between items-center text-[10px] font-black text-slate-700 uppercase tracking-widest"
            >
              <div className="flex items-center space-x-2">
                <svg className={`w-4 h-4 transition-transform ${showFilters ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M19 9l-7 7-7-7" />
                </svg>
                <span>{showFilters ? 'Ukryj Filtry' : 'Pokaż Filtry'}</span>
              </div>
              {hasActiveFilters && (
                <div className="flex items-center space-x-2">
                   <span className="text-blue-600 font-black">Aktywne</span>
                   <span className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></span>
                </div>
              )}
            </button>

            <div className={`${showFilters ? 'block' : 'hidden'} lg:block p-4`}>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Projekt</label>
                  <select 
                    className="w-full border border-slate-100 rounded-xl px-4 py-3 bg-slate-50 outline-none text-xs font-bold focus:ring-2 focus:ring-blue-500 transition-all appearance-none"
                    value={filterProject}
                    onChange={(e) => setFilterProject(e.target.value)}
                  >
                    <option value="">Wszystkie projekty</option>
                    {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                  </select>
                </div>
                
                <div className="space-y-1.5">
                  <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Kategoria</label>
                  <select 
                    className="w-full border border-slate-100 rounded-xl px-4 py-3 bg-slate-50 outline-none text-xs font-bold focus:ring-2 focus:ring-blue-500 transition-all appearance-none"
                    value={filterCategory}
                    onChange={(e) => setFilterCategory(e.target.value)}
                  >
                    <option value="">Wszystkie kategorie</option>
                    {categories.map(cat => <option key={cat.id} value={cat.id}>{cat.name}</option>)}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Od</label>
                  <input 
                    type="date"
                    className="w-full border border-slate-100 rounded-xl px-4 py-3 bg-slate-50 outline-none text-xs font-bold focus:ring-2 focus:ring-blue-500 transition-all"
                    value={filterStartDate}
                    onChange={(e) => setFilterStartDate(e.target.value)}
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Do</label>
                  <input 
                    type="date"
                    className="w-full border border-slate-100 rounded-xl px-4 py-3 bg-slate-50 outline-none text-xs font-bold focus:ring-2 focus:ring-blue-500 transition-all"
                    value={filterEndDate}
                    onChange={(e) => setFilterEndDate(e.target.value)}
                  />
                </div>

                <div className="flex items-end">
                  {hasActiveFilters ? (
                    <button 
                      onClick={resetFilters}
                      className="w-full bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold py-3 rounded-xl text-[9px] uppercase tracking-widest transition-all"
                    >
                      Resetuj filtry
                    </button>
                  ) : (
                    <div className="w-full text-center text-[9px] text-slate-300 font-black uppercase py-3 border border-dashed border-slate-200 rounded-xl">
                      Brak filtrów
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {(isAdding || editingId) && (
        <div className="bg-white p-6 md:p-8 rounded-[1.5rem] md:rounded-[2.5rem] border border-blue-100 shadow-xl animate-in slide-in-from-top duration-400">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-sm font-black text-slate-800 tracking-tight uppercase tracking-widest">
              {editingId ? 'Modyfikacja rekordu' : 'Nowy Rekord Finansowy'}
            </h2>
            <button onClick={() => {setIsAdding(false); setEditingId(null);}} className="text-slate-300 hover:text-slate-600">
               <svg className="w-5 h-5 md:w-6 md:h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" />
               </svg>
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
            <div className="space-y-1.5">
              <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Projekt *</label>
              <select 
                className="w-full px-4 py-3 border border-slate-100 rounded-xl md:rounded-2xl outline-none bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 transition-all font-bold text-sm"
                value={editingId ? editFormData.projectId : formData.projectId}
                onChange={(e) => editingId ? setEditFormData({...editFormData, projectId: e.target.value}) : setFormData({...formData, projectId: e.target.value})}
              >
                <option value="">Wybierz projekt...</option>
                {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </div>
            <div className="space-y-1.5">
              <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Kategoria *</label>
              <select 
                className="w-full px-4 py-3 border border-slate-100 rounded-xl md:rounded-2xl outline-none bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 transition-all font-bold text-sm"
                value={editingId ? editFormData.categoryId : formData.categoryId}
                onChange={(e) => editingId ? setEditFormData({...editFormData, categoryId: e.target.value}) : setFormData({...formData, categoryId: e.target.value})}
              >
                <option value="">Wybierz kategorię...</option>
                {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div className="space-y-1.5">
              <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Kwota (PLN) *</label>
              <input 
                type="number"
                placeholder="0.00"
                className="w-full px-4 py-3 border border-slate-100 rounded-xl md:rounded-2xl outline-none bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 transition-all font-black text-lg text-blue-600"
                value={editingId ? editFormData.amount : formData.amount}
                onChange={(e) => editingId ? setEditFormData({...editFormData, amount: parseFloat(e.target.value)}) : setFormData({...formData, amount: e.target.value})}
              />
            </div>
            <div className="space-y-1.5">
              <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Data *</label>
              <input 
                type="date"
                className="w-full px-4 py-3 border border-slate-100 rounded-xl md:rounded-2xl outline-none bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 transition-all font-bold text-sm"
                value={editingId ? editFormData.date : formData.date}
                onChange={(e) => editingId ? setEditFormData({...editFormData, date: e.target.value}) : setFormData({...formData, date: e.target.value})}
              />
            </div>
            <div className="md:col-span-2 space-y-1.5">
              <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Opis opcjonalny</label>
              <input 
                placeholder="Notatka do wydatku"
                className="w-full px-4 py-3 border border-slate-100 rounded-xl md:rounded-2xl outline-none bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 transition-all font-medium text-sm"
                value={editingId ? editFormData.description : formData.description}
                onChange={(e) => editingId ? setEditFormData({...editFormData, description: e.target.value}) : setFormData({...formData, description: e.target.value})}
              />
            </div>
          </div>
          <div className="mt-8 flex flex-col sm:flex-row gap-3">
            <button 
              onClick={editingId ? handleSaveEdit : handleAdd} 
              className="flex-1 bg-blue-600 text-white px-6 py-4 rounded-xl md:rounded-2xl hover:bg-blue-700 transition-all font-black text-center active:scale-95 shadow-md uppercase tracking-widest text-[10px]"
            >
              {editingId ? 'Zapisz Zmiany' : 'Dodaj Rekord'}
            </button>
            <button 
              onClick={() => {setIsAdding(false); setEditingId(null);}} 
              className="flex-1 bg-slate-100 text-slate-500 px-6 py-4 rounded-xl md:rounded-2xl hover:bg-slate-200 transition-all font-black text-center active:scale-95 uppercase tracking-widest text-[10px]"
            >
              Anuluj
            </button>
          </div>
        </div>
      )}

      {viewMode === 'list' ? (
        <>
          <div className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] px-2 flex justify-between items-center">
            <span>Znaleziono: {filteredCosts.length} pozycji</span>
            {hasActiveFilters && <span className="text-blue-500 font-bold">Zastosowano filtry</span>}
          </div>

          <div className="hidden lg:block bg-white rounded-[2rem] shadow-sm border border-slate-50 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-slate-50/50 border-b border-slate-100">
                  <tr>
                    <th className="px-8 py-5 text-[9px] font-black text-slate-400 uppercase tracking-widest">Data</th>
                    <th className="px-8 py-5 text-[9px] font-black text-slate-400 uppercase tracking-widest">Projekt</th>
                    <th className="px-8 py-5 text-[9px] font-black text-slate-400 uppercase tracking-widest">Kategoria</th>
                    <th className="px-8 py-5 text-[9px] font-black text-slate-400 uppercase tracking-widest text-right">Kwota</th>
                    <th className="px-8 py-5 text-[9px] font-black text-slate-400 uppercase tracking-widest text-center">Akcje</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {filteredCosts.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-8 py-16 text-center text-slate-300 font-medium italic">Brak danych dla wybranych filtrów.</td>
                    </tr>
                  ) : (
                    filteredCosts.map(cost => {
                      const proj = projects.find(p => p.id === cost.projectId);
                      const cat = categories.find(c => c.id === cost.categoryId);
                      const isQuickEditing = quickEditingId === cost.id;

                      return (
                        <tr 
                          key={cost.id} 
                          className={`transition-colors group ${isQuickEditing ? 'bg-blue-50/50' : 'hover:bg-blue-50/20'}`}
                        >
                          <td className="px-8 py-4">
                            {isQuickEditing ? (
                              <input 
                                type="date"
                                className="bg-white border border-blue-200 rounded-lg px-2 py-1 text-xs font-bold outline-none focus:ring-2 focus:ring-blue-500"
                                value={quickEditData.date}
                                onChange={(e) => setQuickEditData({...quickEditData, date: e.target.value})}
                              />
                            ) : (
                              <span className="text-xs text-slate-500 font-medium">{cost.date}</span>
                            )}
                          </td>
                          <td className="px-8 py-4 text-xs font-black text-slate-900">{proj?.name || '—'}</td>
                          <td className="px-8 py-4 text-xs">
                            <span className="bg-slate-100 text-slate-500 px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-tight">
                              {cat?.name || 'Inne'}
                            </span>
                          </td>
                          <td className="px-8 py-4 text-right">
                            {isQuickEditing ? (
                              <div className="flex items-center justify-end space-x-2">
                                 <input 
                                    type="number"
                                    className="w-24 bg-white border border-blue-200 rounded-lg px-2 py-1 text-xs font-black text-right outline-none focus:ring-2 focus:ring-blue-500"
                                    value={quickEditData.amount}
                                    onChange={(e) => setQuickEditData({...quickEditData, amount: parseFloat(e.target.value)})}
                                    onKeyDown={(e) => e.key === 'Enter' && handleSaveQuickEdit(cost.id, e as any)}
                                 />
                                 <span className="text-[9px] font-black text-slate-400">PLN</span>
                              </div>
                            ) : (
                              <span className="text-sm font-black text-slate-900 whitespace-nowrap">
                                {cost.amount.toLocaleString('pl-PL')} <span className="text-[9px] font-medium text-slate-400">PLN</span>
                              </span>
                            )}
                          </td>
                          <td className="px-8 py-4">
                            <div className={`flex justify-center space-x-1 transition-all ${isQuickEditing ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}>
                              {isQuickEditing ? (
                                <>
                                  <button 
                                    onClick={(e) => handleSaveQuickEdit(cost.id, e)} 
                                    className="p-2 bg-emerald-500 text-white rounded-lg hover:bg-emerald-600 transition-all shadow-sm"
                                    title="Zapisz"
                                  >
                                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                                    </svg>
                                  </button>
                                  <button 
                                    onClick={(e) => { e.stopPropagation(); setQuickEditingId(null); }} 
                                    className="p-2 bg-slate-100 text-slate-400 rounded-lg hover:bg-slate-200 transition-all"
                                    title="Anuluj"
                                  >
                                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                  </button>
                                </>
                              ) : (
                                <>
                                  <button 
                                    onClick={(e) => startQuickEdit(cost, e)} 
                                    className="p-2 hover:bg-emerald-50 hover:text-emerald-600 rounded-lg text-slate-400 transition-all"
                                    title="Szybka edycja"
                                  >
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                      <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/>
                                    </svg>
                                  </button>
                                  <button onClick={() => startEditing(cost)} className="p-2 hover:bg-blue-50 hover:text-blue-600 rounded-lg text-slate-400 transition-all" title="Pełna edycja"><PencilIcon size={16} /></button>
                                  <button onClick={(e) => handleDelete(cost.id, e)} className="p-2 hover:bg-red-50 hover:text-red-600 rounded-lg text-slate-400 transition-all" title="Usuń"><TrashIcon size={16} /></button>
                                </>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="lg:hidden space-y-4">
            {filteredCosts.length === 0 ? (
              <div className="py-20 text-center bg-white rounded-[2rem] border border-slate-100 text-slate-300">
                <ReceiptIcon size={64} className="mx-auto mb-4 opacity-50" />
                <p className="text-[10px] font-black uppercase tracking-widest">Brak zarejestrowanych kosztów</p>
              </div>
            ) : (
              filteredCosts.map(cost => {
                const proj = projects.find(p => p.id === cost.projectId);
                const cat = categories.find(c => c.id === cost.categoryId);
                const isExpanded = expandedId === cost.id;
                
                return (
                  <div 
                    key={cost.id} 
                    className={`bg-white rounded-2xl shadow-sm border transition-all active:scale-[0.98] overflow-hidden ${isExpanded ? 'border-blue-400 ring-4 ring-blue-50' : 'border-slate-100'}`}
                    onClick={() => toggleExpand(cost.id)}
                  >
                    <div className="p-4 md:p-5">
                      <div className="flex justify-between items-start">
                        <div className="space-y-1">
                          <div className="text-[8px] font-black text-slate-400 uppercase tracking-widest">{cost.date}</div>
                          <div className="font-black text-slate-900 text-base leading-tight truncate max-w-[150px]">{proj?.name || '—'}</div>
                          <div className="pt-1">
                            <span className="bg-slate-50 text-slate-400 px-2 py-0.5 rounded-md text-[8px] font-black uppercase tracking-widest border border-slate-100">
                              {cat?.name || 'Inne'}
                            </span>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-lg font-black text-slate-900 leading-none">{cost.amount.toLocaleString('pl-PL')}</div>
                          <div className="text-[8px] font-black text-slate-400 mt-1 uppercase tracking-widest">PLN</div>
                        </div>
                      </div>
                      
                      {isExpanded && (
                        <div className="mt-4 pt-4 border-t border-slate-50 animate-in fade-in duration-300">
                          {cost.description && (
                            <div className="mb-4">
                              <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Opis wydatku:</p>
                              <p className="text-xs text-slate-600 font-semibold leading-relaxed bg-slate-50 p-3 rounded-xl">{cost.description}</p>
                            </div>
                          )}
                          
                          <div className="flex gap-2">
                            <button 
                              onClick={(e) => { e.stopPropagation(); startEditing(cost); }}
                              className="flex-1 bg-slate-900 text-white py-3 rounded-xl text-[9px] font-black uppercase tracking-widest flex items-center justify-center space-x-2"
                            >
                              <PencilIcon size={14} />
                              <span>Edytuj</span>
                            </button>
                            <button 
                              onClick={(e) => { e.stopPropagation(); handleDelete(cost.id, e); }}
                              className="flex-1 bg-red-50 text-red-600 py-3 rounded-xl text-[9px] font-black uppercase tracking-widest flex items-center justify-center space-x-2"
                            >
                              <TrashIcon size={14} />
                              <span>Usuń</span>
                            </button>
                          </div>
                        </div>
                      )}

                      {!isExpanded && cost.description && (
                        <div className="mt-3 flex items-center justify-center opacity-30">
                          <div className="w-10 h-1 bg-slate-200 rounded-full"></div>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </>
      ) : (
        /* Calendar View Section */
        <div className="animate-in fade-in duration-500">
          <div className="bg-white rounded-[2rem] shadow-xl border border-slate-100 overflow-hidden">
            <div className="p-4 sm:p-6 bg-slate-900 text-white flex justify-between items-center">
              <button 
                onClick={() => changeMonth(-1)}
                className="p-2 hover:bg-white/10 rounded-xl transition-all"
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h2 className="text-sm font-black uppercase tracking-[0.2em]">
                {currentCalendarDate.toLocaleString('pl-PL', { month: 'long', year: 'numeric' })}
              </h2>
              <button 
                onClick={() => changeMonth(1)}
                className="p-2 hover:bg-white/10 rounded-xl transition-all"
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M9 5l7 7-7 7" />
                </svg>
              </button>
            </div>
            
            <div className="grid grid-cols-7 gap-px bg-slate-100 border-b border-slate-100">
              {['Pon', 'Wt', 'Śr', 'Czw', 'Pt', 'Sob', 'Ndz'].map(day => (
                <div key={day} className="bg-slate-50 py-3 text-center text-[9px] font-black text-slate-400 uppercase tracking-widest">
                  {day}
                </div>
              ))}
            </div>

            <div className="grid grid-cols-7 gap-px bg-slate-100">
              {calendarDays.map((day, idx) => (
                <div 
                  key={idx} 
                  className={`bg-white min-h-[80px] sm:min-h-[120px] p-2 sm:p-4 transition-colors relative group ${day.type === 'empty' ? 'bg-slate-50/50' : 'hover:bg-blue-50/20'}`}
                  onClick={() => {
                    if (day.type === 'day' && day.hasCosts) {
                      setFilterStartDate(day.fullDate!);
                      setFilterEndDate(day.fullDate!);
                      setViewMode('list');
                      setShowFilters(true);
                    }
                  }}
                >
                  {day.type === 'day' && (
                    <>
                      <div className="flex justify-between items-start">
                        <span className={`text-[10px] sm:text-xs font-black ${day.hasCosts ? 'text-blue-600' : 'text-slate-300'}`}>
                          {day.date}
                        </span>
                        {day.hasCosts && (
                           <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse"></div>
                        )}
                      </div>
                      {day.hasCosts && (
                        <div className="mt-2 sm:mt-4 space-y-1">
                          <div className="text-[10px] sm:text-sm font-black text-slate-900 leading-none">
                            {day.total?.toLocaleString('pl-PL')}
                          </div>
                          <div className="text-[7px] sm:text-[9px] font-black text-slate-400 uppercase tracking-tighter">
                            PLN
                          </div>
                        </div>
                      )}
                      {day.hasCosts && (
                         <div className="absolute inset-0 opacity-0 group-hover:opacity-100 bg-blue-600/5 flex items-center justify-center pointer-events-none transition-opacity">
                            <span className="text-[8px] font-black uppercase bg-blue-600 text-white px-2 py-1 rounded-full shadow-lg">
                              Pokaż detale
                            </span>
                         </div>
                      )}
                    </>
                  )}
                </div>
              ))}
            </div>
          </div>
          <div className="mt-6 flex items-center justify-center space-x-4">
             <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span className="text-[9px] font-black uppercase text-slate-400 tracking-widest">Dni z wydatkami</span>
             </div>
             <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-slate-200 rounded-full"></div>
                <span className="text-[9px] font-black uppercase text-slate-400 tracking-widest">Dni wolne od kosztów</span>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CostTracker;
