
# 💰 BudgetPro Premium - PWA

Profesjonalne narzędzie do zarządzania budżetem projektów. Aplikacja działa jako PWA (można ją zainstalować na telefonie).

## 🚀 Jak wrzucić to na GitHub?

1. **Załóż nowe repozytorium** na GitHub (np. o nazwie `budget-app`).
2. **Skopiuj wszystkie pliki** z tego projektu do folderu na swoim komputerze.
3. **Zainicjalizuj Git** w tym folderze:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/TWOJA-NAZWA/budget-app.git
   git push -u origin main
   ```
4. **Włącz GitHub Pages**:
   - Wejdź w zakładkę **Settings** -> **Pages** swojego repozytorium.
   - W sekcji **Build and deployment** -> **Source** wybierz **GitHub Actions**.

## 📱 Jak zainstalować na telefonie?

Po zakończeniu automatycznego wdrażania (zakładka **Actions**), Twoja aplikacja będzie dostępna pod adresem:
`https://TWOJA-NAZWA.github.io/budget-app/`

1. Otwórz ten link w telefonie.
2. Kliknij "Udostępnij" (Safari) lub "Menu" (Chrome).
3. Wybierz **"Dodaj do ekranu głównego"**.

## 🛠️ Rozwój lokalny

```bash
npm install
npm run dev
```
