
import React, { useState } from 'react';
import { User } from '../types';
import { LogoIcon } from './Icons';
import { useToast } from './Toast';

interface AuthProps {
  onLogin: (user: User) => void;
}

const STORAGE_USERS_KEY = 'budgetpro_users';

const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const { showToast } = useToast();

  const getUsers = (): User[] => {
    try {
      const saved = localStorage.getItem(STORAGE_USERS_KEY);
      if (!saved) return [];
      const parsed = JSON.parse(saved);
      return Array.isArray(parsed) ? parsed : [];
    } catch (error) {
      console.error('Błąd podczas odczytu bazy użytkowników:', error);
      showToast('Wystąpił problem z odczytem bazy danych użytkowników.', 'error');
      // Próba naprawy: jeśli dane są uszkodzone, czyścimy klucz (opcjonalne, ale bezpieczniejsze)
      // localStorage.removeItem(STORAGE_USERS_KEY);
      return [];
    }
  };

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    const users = getUsers();

    if (isLogin) {
      const user = users.find(u => u.email === email && u.password === password);
      if (user) {
        showToast(`Witaj ponownie, ${user.name}!`, 'success');
        onLogin(user);
      } else {
        showToast('Błędny email lub hasło.', 'error');
      }
    } else {
      if (!name || !email || !password) {
        showToast('Wypełnij wszystkie pola.', 'error');
        return;
      }
      if (users.some(u => u.email === email)) {
        showToast('Użytkownik o tym adresie email już istnieje.', 'error');
        return;
      }

      const newUser: User = {
        id: crypto.randomUUID(),
        name,
        email,
        password
      };

      try {
        const updatedUsers = [...users, newUser];
        localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(updatedUsers));
        showToast('Konto zostało utworzone!', 'success');
        onLogin(newUser);
      } catch (error) {
        console.error('Błąd podczas zapisu użytkownika:', error);
        if (error instanceof DOMException && error.name === 'QuotaExceededError') {
          showToast('Brak miejsca w pamięci przeglądarki na utworzenie nowego konta.', 'error');
        } else {
          showToast('Wystąpił nieoczekiwany błąd podczas tworzenia konta.', 'error');
        }
      }
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-900 px-4 py-12">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-indigo-600/20 rounded-full blur-3xl"></div>
      </div>

      <div className="w-full max-w-md bg-white/10 backdrop-blur-xl border border-white/10 p-8 rounded-3xl shadow-2xl relative z-10">
        <div className="flex flex-col items-center mb-10 text-center">
          <div className="bg-blue-600 p-3 rounded-2xl shadow-lg shadow-blue-500/30 mb-4">
            <LogoIcon size={40} className="text-white" />
          </div>
          <h1 className="text-3xl font-black text-white tracking-tighter">BudgetPro</h1>
          <p className="text-slate-400 text-sm mt-1 uppercase tracking-widest font-bold">Premium Budgeting</p>
        </div>

        <form onSubmit={handleAuth} className="space-y-5">
          {!isLogin && (
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1">Imię i nazwisko</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-800/50 border border-white/5 rounded-2xl px-5 py-4 text-white outline-none focus:ring-2 focus:ring-blue-500 transition-all placeholder:text-slate-600"
                placeholder="Jan Kowalski"
              />
            </div>
          )}

          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1">Adres Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-slate-800/50 border border-white/5 rounded-2xl px-5 py-4 text-white outline-none focus:ring-2 focus:ring-blue-500 transition-all placeholder:text-slate-600"
              placeholder="twoj@email.com"
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1">Hasło</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-slate-800/50 border border-white/5 rounded-2xl px-5 py-4 text-white outline-none focus:ring-2 focus:ring-blue-500 transition-all placeholder:text-slate-600"
              placeholder="••••••••"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-2xl transition-all shadow-xl shadow-blue-600/20 active:scale-95 mt-4"
          >
            {isLogin ? 'Zaloguj się' : 'Stwórz konto'}
          </button>
        </form>

        <div className="mt-8 text-center">
          <button
            onClick={() => setIsLogin(!isLogin)}
            className="text-slate-400 hover:text-white transition-colors text-sm font-medium"
          >
            {isLogin ? (
              <>Nie masz konta? <span className="text-blue-400 font-bold">Zarejestruj się</span></>
            ) : (
              <>Masz już konto? <span className="text-blue-400 font-bold">Zaloguj się</span></>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Auth;
