
import React, { useMemo, useState } from 'react';
import { Project, Category, CostRecord } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import ExcelExport from './ExcelExport';
import { PlusIcon, ReceiptIcon, LayersIcon, DashboardIcon } from './Icons';
import { useToast } from './Toast';
import { GoogleGenAI } from "@google/genai";

interface DashboardProps {
  projects: Project[];
  categories: Category[];
  costs: CostRecord[];
  setCosts: React.Dispatch<React.SetStateAction<CostRecord[]>>;
}

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#6366f1', '#06b6d4', '#84cc16'];

const Dashboard: React.FC<DashboardProps> = ({ projects, categories, costs, setCosts }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);
  const { showToast } = useToast();
  
  const [formData, setFormData] = useState({
    projectId: '',
    categoryId: '',
    amount: '',
    date: new Date().toISOString().split('T')[0],
    description: ''
  });

  const totalSpend = useMemo(() => costs.reduce((sum, c) => sum + c.amount, 0), [costs]);

  const spendByProject = useMemo(() => {
    return projects.map(p => ({
      name: p.name,
      value: costs.filter(c => c.projectId === p.id).reduce((sum, c) => sum + c.amount, 0)
    })).filter(p => p.value > 0);
  }, [projects, costs]);

  const spendByCategory = useMemo(() => {
    return categories.map(cat => ({
      name: cat.name,
      value: costs.filter(c => c.categoryId === cat.id).reduce((sum, c) => sum + c.amount, 0)
    })).filter(c => c.value > 0);
  }, [categories, costs]);

  const runSmartAudit = async () => {
    if (costs.length === 0) {
      showToast("Brak danych do analizy.", "info");
      return;
    }
    
    setIsAnalyzing(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `Przeanalizuj poniższe dane finansowe projektów i podaj 3 konkretne rady oszczędnościowe lub spostrzeżenia. 
      Dane (wydatki): ${JSON.stringify(costs.slice(0, 50))}
      Projekty: ${JSON.stringify(projects)}
      Kategorie: ${JSON.stringify(categories)}
      Odpowiedz krótko i profesjonalnie w języku polskim.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });

      setAnalysisResult(response.text || "Brak wniosków.");
      showToast("Analiza serwerowa ukończona.", "success");
    } catch (error) {
      console.error('Audit Error:', error);
      showToast("Błąd analizy AI.", "error");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleQuickAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.projectId || !formData.categoryId || !formData.amount) {
      showToast('Wypełnij wymagane pola!', 'error');
      return;
    }

    const newRecord: CostRecord = {
      id: crypto.randomUUID(),
      projectId: formData.projectId,
      categoryId: formData.categoryId,
      amount: parseFloat(formData.amount),
      date: formData.date,
      description: formData.description
    };

    setCosts(prev => [newRecord, ...prev]);
    setIsModalOpen(false);
    setFormData({
      projectId: '',
      categoryId: '',
      amount: '',
      date: new Date().toISOString().split('T')[0],
      description: ''
    });
    showToast('Zapisano na serwerze.', 'success');
  };

  return (
    <div className="space-y-6 md:space-y-8 animate-in fade-in duration-500 pb-12">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight leading-none">Console Finansowa</h1>
          <p className="text-slate-500 text-xs font-bold uppercase tracking-widest mt-2">Server-Side Analytics</p>
        </div>
        <div className="flex items-center space-x-2 w-full sm:w-auto">
          <button 
            onClick={runSmartAudit}
            disabled={isAnalyzing}
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-3 rounded-2xl flex items-center space-x-2 font-black shadow-lg transition-all active:scale-95 text-[10px] uppercase tracking-widest disabled:opacity-50"
          >
            {isAnalyzing ? "Analiza..." : "Smart Audit (AI)"}
          </button>
          <button 
            onClick={() => setIsModalOpen(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-3 rounded-2xl flex items-center space-x-2 font-black shadow-lg transition-all active:scale-95 text-[10px] uppercase tracking-widest"
          >
            <PlusIcon size={16} />
            <span>Nowy Wpis</span>
          </button>
        </div>
      </div>

      {analysisResult && (
        <div className="bg-indigo-900 text-indigo-100 p-6 rounded-[2rem] shadow-xl animate-in slide-in-from-top-4 duration-500 relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
            <svg width="100" height="100" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L4.5 20.29l.71.71L12 18l6.79 3 .71-.71L12 2z"/></svg>
          </div>
          <div className="flex justify-between items-start mb-4">
            <h3 className="text-xs font-black uppercase tracking-[0.2em] flex items-center">
              <span className="w-2 h-2 bg-indigo-400 rounded-full mr-3 animate-pulse"></span>
              Raport Inteligentnego Audytora (Gemini)
            </h3>
            <button onClick={() => setAnalysisResult(null)} className="text-indigo-400 hover:text-white">✕</button>
          </div>
          <div className="text-sm leading-relaxed font-medium whitespace-pre-wrap">
            {analysisResult}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 md:gap-8">
        <div className="bg-white p-5 md:p-6 rounded-[1.5rem] md:rounded-[2rem] shadow-sm border border-slate-100 flex items-center space-x-4 relative overflow-hidden group">
          <div className="bg-blue-600 p-3 md:p-4 rounded-xl md:rounded-2xl text-white shadow-lg shadow-blue-100 relative z-10">
            <ReceiptIcon size={20} />
          </div>
          <div className="relative z-10">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-0.5 md:mb-1">Budżet Operacyjny</p>
            <p className="text-xl md:text-2xl font-black text-slate-900">{totalSpend.toLocaleString('pl-PL')} <span className="text-[10px] md:text-xs font-bold text-slate-400 uppercase">PLN</span></p>
          </div>
        </div>
        
        <div className="bg-white p-5 md:p-6 rounded-[1.5rem] md:rounded-[2rem] shadow-sm border border-slate-100 flex items-center space-x-4 relative overflow-hidden group">
          <div className="bg-emerald-600 p-3 md:p-4 rounded-xl md:rounded-2xl text-white shadow-lg shadow-emerald-100 relative z-10">
            <LayersIcon size={20} />
          </div>
          <div className="relative z-10">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-0.5 md:mb-1">Projekty na Serwerze</p>
            <p className="text-xl md:text-2xl font-black text-emerald-600">{projects.length}</p>
          </div>
        </div>

        <div className="bg-white p-5 md:p-6 rounded-[1.5rem] md:rounded-[2rem] shadow-sm border border-slate-100 flex items-center space-x-4 relative overflow-hidden group">
          <div className="bg-indigo-600 p-3 md:p-4 rounded-xl md:rounded-2xl text-white shadow-lg shadow-indigo-100 relative z-10">
            <DashboardIcon size={20} />
          </div>
          <div className="relative z-10">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-0.5 md:mb-1">Średnia Kosztowa</p>
            <p className="text-xl md:text-2xl font-black text-slate-900">
              {projects.length ? (totalSpend / projects.length).toLocaleString('pl-PL', { maximumFractionDigits: 0 }) : 0} <span className="text-[10px] md:text-xs font-bold text-slate-400 uppercase">PLN</span>
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="lg:col-span-2 bg-white p-5 md:p-8 rounded-[1.5rem] md:rounded-[2.5rem] shadow-sm border border-slate-100">
          <h2 className="text-sm md:text-lg font-black text-slate-900 mb-6 md:mb-8 flex items-center">
            <span className="w-1.5 h-4 md:w-2 md:h-6 bg-blue-600 rounded-full mr-3 md:mr-4"></span>
            Rozkład Budżetu (Serwer)
          </h2>
          <div className="h-64 md:h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={spendByProject} margin={{ top: 0, right: 0, left: -25, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 9, fontWeight: 'bold', fill: '#94a3b8'}} />
                <YAxis axisLine={false} tickLine={false} tick={{fontSize: 9, fontWeight: 'bold', fill: '#94a3b8'}} />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', padding: '10px' }}
                  cursor={{fill: '#f8fafc'}}
                />
                <Bar dataKey="value" fill="#2563eb" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* New Pie Chart for Projects Share */}
        <div className="bg-white p-5 md:p-8 rounded-[1.5rem] md:rounded-[2.5rem] shadow-sm border border-slate-100">
          <h2 className="text-sm md:text-lg font-black text-slate-900 mb-6 md:mb-8 flex items-center">
             <span className="w-1.5 h-4 md:w-2 md:h-6 bg-emerald-500 rounded-full mr-3 md:mr-4"></span>
             Udział Projektów
          </h2>
          <div className="h-64 md:h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={spendByProject}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ percent }) => `${(percent * 100).toFixed(0)}%`}
                  outerRadius="80%"
                  dataKey="value"
                  strokeWidth={0}
                >
                  {spendByProject.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => `${value.toLocaleString('pl-PL')} PLN`} />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '9px', fontWeight: 'bold', paddingTop: '10px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-5 md:p-8 rounded-[1.5rem] md:rounded-[2.5rem] shadow-sm border border-slate-100">
          <h2 className="text-sm md:text-lg font-black text-slate-900 mb-6 md:mb-8 flex items-center">
             <span className="w-1.5 h-4 md:w-2 md:h-6 bg-orange-500 rounded-full mr-3 md:mr-4"></span>
             Kategorie Serwerowe
          </h2>
          <div className="h-64 md:h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={spendByCategory}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ percent }) => `${(percent * 100).toFixed(0)}%`}
                  outerRadius="80%"
                  dataKey="value"
                  strokeWidth={0}
                >
                  {spendByCategory.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[(index + 4) % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => `${value.toLocaleString('pl-PL')} PLN`} />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '9px', fontWeight: 'bold', paddingTop: '10px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div 
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-300"
            onClick={() => setIsModalOpen(false)}
          ></div>
          <div className="bg-white w-full max-w-lg rounded-t-[2rem] sm:rounded-[2.5rem] shadow-2xl relative z-10 overflow-hidden animate-in slide-in-from-bottom duration-400">
            <div className="p-6 md:p-8">
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h2 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight">Szybki Wydatek</h2>
                  <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mt-0.5">Zapis zostanie przesłany na serwer</p>
                </div>
                <button 
                  onClick={() => setIsModalOpen(false)}
                  className="p-2 md:p-3 bg-slate-100 text-slate-400 hover:text-slate-900 rounded-xl transition-all"
                >
                   ✕
                </button>
              </div>

              <form onSubmit={handleQuickAdd} className="space-y-4 md:space-y-6">
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Projekt *</label>
                  <select 
                    required
                    className="w-full bg-slate-50 border border-slate-200 px-4 py-3.5 rounded-xl md:rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 font-bold transition-all text-sm"
                    value={formData.projectId}
                    onChange={(e) => setFormData({...formData, projectId: e.target.value})}
                  >
                    <option value="">Wybierz projekt...</option>
                    {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                  </select>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Kategoria *</label>
                    <select 
                      required
                      className="w-full bg-slate-50 border border-slate-200 px-4 py-3.5 rounded-xl md:rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 font-bold transition-all text-sm"
                      value={formData.categoryId}
                      onChange={(e) => setFormData({...formData, categoryId: e.target.value})}
                    >
                      <option value="">Wybierz kategorię...</option>
                      {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Kwota (PLN) *</label>
                    <input 
                      required
                      type="number"
                      step="0.01"
                      placeholder="0.00"
                      className="w-full bg-slate-50 border border-slate-200 px-4 py-3.5 rounded-xl md:rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 font-black text-lg md:text-xl text-blue-600 transition-all"
                      value={formData.amount}
                      onChange={(e) => setFormData({...formData, amount: e.target.value})}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Data operacji</label>
                  <input 
                    type="date"
                    className="w-full bg-slate-50 border border-slate-200 px-4 py-3.5 rounded-xl md:rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 font-bold text-sm"
                    value={formData.date}
                    onChange={(e) => setFormData({...formData, date: e.target.value})}
                  />
                </div>

                <button 
                  type="submit"
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-4 md:py-5 rounded-2xl md:rounded-[2rem] transition-all shadow-xl shadow-blue-500/20 active:scale-95 mt-2 uppercase tracking-widest text-[10px] md:text-xs"
                >
                  Prześlij na Serwer
                </button>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
