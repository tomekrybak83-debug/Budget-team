
export interface Category {
  id: string;
  name: string;
  isDefault: boolean;
}

export type ProjectStatus = 'active' | 'completed' | 'on-hold';

export interface Project {
  id: string;
  name: string;
  description: string;
  createdAt: number;
  status: ProjectStatus;
}

export interface CostRecord {
  id: string;
  projectId: string;
  categoryId: string;
  amount: number;
  date: string; // ISO string YYYY-MM-DD
  description: string;
}

export interface MonthlySummary {
  month: string; // YYYY-MM
  total: number;
  byCategory: Record<string, number>;
}

export interface User {
  id: string;
  name: string;
  email: string;
  password?: string;
  googleDriveEnabled?: boolean;
  googleFileId?: string;
  lastSyncAt?: number;
  customLogoUrl?: string;
}
