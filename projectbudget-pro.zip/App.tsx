
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Layout, DashboardIcon, LayersIcon, ReceiptIcon, SettingsIcon, LogoIcon, LogOutIcon, DownloadIcon } from './components/Icons';
import Dashboard from './components/Dashboard';
import ProjectList from './components/ProjectList';
import CostTracker from './components/CostTracker';
import Settings from './components/Settings';
import Auth from './components/Auth';
import { Project, Category, CostRecord, User } from './types';
import { DEFAULT_CATEGORIES, APP_STORAGE_KEY } from './constants';
import { ToastProvider, useToast } from './components/Toast';
import { api } from './api';

type Tab = 'dashboard' | 'projects' | 'costs' | 'settings';

const STORAGE_SESSION_KEY = 'budgetpro_session';
const BACKUP_FILENAME = 'BudgetPro_AutoBackup.json';

const AppContent: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [projects, setProjects] = useState<Project[]>([]);
  const [categories, setCategories] = useState<Category[]>(DEFAULT_CATEGORIES);
  const [costs, setCosts] = useState<CostRecord[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);
  const [isInitialLoading, setIsInitialLoading] = useState(false);
  const [syncStatus, setSyncStatus] = useState<'idle' | 'syncing' | 'synced' | 'error'>('idle');
  const [serverStatus, setServerStatus] = useState<'connected' | 'syncing' | 'offline'>('connected');
  const [googleAccessToken, setGoogleAccessToken] = useState<string | null>(null);
  
  const { showToast } = useToast();
  const syncTimeoutRef = useRef<number | null>(null);
  const lastSyncedHashRef = useRef<string>('');
  const isSyncingRef = useRef<boolean>(false);

  const getPageTitle = () => {
    switch (activeTab) {
      case 'dashboard': return 'Dashboard';
      case 'projects': return 'Projekty';
      case 'costs': return 'Ewidencja Kosztów';
      case 'settings': return 'Ustawienia';
      default: return 'BudgetPro';
    }
  };

  useEffect(() => {
    const savedSession = localStorage.getItem(STORAGE_SESSION_KEY);
    if (savedSession) {
      try {
        const user = JSON.parse(savedSession);
        setCurrentUser(user);
      } catch (e) {
        localStorage.removeItem(STORAGE_SESSION_KEY);
      }
    }
    setIsLoaded(true);
  }, []);

  useEffect(() => {
    const loadFromServer = async () => {
      if (currentUser?.id) {
        setIsInitialLoading(true);
        setServerStatus('syncing');
        try {
          const data = await api.fetchAllData(currentUser.id);
          setProjects(data.projects || []);
          setCategories(data.categories.length > 0 ? data.categories : DEFAULT_CATEGORIES);
          setCosts(data.costs || []);
          setServerStatus('connected');
          lastSyncedHashRef.current = JSON.stringify({ 
            projects: data.projects, 
            categories: data.categories, 
            costs: data.costs 
          });
        } catch (error) {
          setServerStatus('offline');
          showToast('Błąd pobierania danych z serwera.', 'error');
        } finally {
          setIsInitialLoading(false);
        }
      }
    };
    loadFromServer();
  }, [currentUser?.id, showToast]);

  const performSync = useCallback(async () => {
    if (!currentUser?.id || isSyncingRef.current) return;

    const currentData = { projects, categories, costs };
    const currentHash = JSON.stringify(currentData);
    
    if (currentHash === lastSyncedHashRef.current) return;

    try {
      isSyncingRef.current = true;
      setServerStatus('syncing');
      await api.syncAll(currentUser.id, currentData);
      
      if (googleAccessToken && currentUser.googleDriveEnabled) {
        setSyncStatus('syncing');
        setSyncStatus('synced');
      }

      setServerStatus('connected');
      lastSyncedHashRef.current = currentHash;
    } catch (error) {
      setServerStatus('offline');
      setSyncStatus('error');
    } finally {
      isSyncingRef.current = false;
    }
  }, [projects, categories, costs, currentUser, googleAccessToken]);

  useEffect(() => {
    if (syncTimeoutRef.current) window.clearTimeout(syncTimeoutRef.current);
    syncTimeoutRef.current = window.setTimeout(performSync, 2000);
  }, [projects, categories, costs, performSync]);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem(STORAGE_SESSION_KEY, JSON.stringify(user));
  };

  const handleLogout = () => {
    if (confirm("Wylogować? Dane na serwerze są bezpieczne.")) {
      setCurrentUser(null);
      setGoogleAccessToken(null);
      localStorage.removeItem(STORAGE_SESSION_KEY);
      showToast('Wylogowano z serwera.', 'info');
    }
  };

  if (!isLoaded || isInitialLoading) return (
    <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center">
      <LogoIcon size={80} className="text-blue-500 animate-pulse mb-6" />
      <div className="text-blue-500 font-black tracking-[0.3em] text-[10px] uppercase animate-pulse text-center px-4">Synchronizacja danych...</div>
    </div>
  );

  if (!currentUser) return <Auth onLogin={handleLogin} />;

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-slate-50 font-sans selection:bg-blue-100 selection:text-blue-900 overflow-x-hidden">
      {/* Desktop Sidebar */}
      <nav className="hidden md:flex flex-col w-72 bg-slate-900 text-white p-6 space-y-8 sticky top-0 h-screen shadow-2xl z-20">
        <div className="flex items-center space-x-3 px-2">
          <LogoIcon customUrl={currentUser.customLogoUrl} className="text-blue-500 animate-pulse-slow" size={42} />
          <div>
            <div className="text-xl font-black tracking-tight text-white leading-tight">BudgetPro</div>
            <div className="text-[10px] font-bold text-slate-500 tracking-widest uppercase">Server Edition</div>
          </div>
        </div>
        
        <div className="flex flex-col space-y-1">
          <NavItem active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} icon={<DashboardIcon />} label="Dashboard" />
          <NavItem active={activeTab === 'projects'} onClick={() => setActiveTab('projects')} icon={<LayersIcon />} label="Projekty" />
          <NavItem active={activeTab === 'costs'} onClick={() => setActiveTab('costs')} icon={<ReceiptIcon />} label="Ewidencja Kosztów" />
          <NavItem active={activeTab === 'settings'} onClick={() => setActiveTab('settings')} icon={<SettingsIcon />} label="Ustawienia" />
        </div>
        
        <div className="mt-auto space-y-4">
          <div className="px-4 py-3 bg-slate-800/40 rounded-2xl border border-white/5 backdrop-blur-sm">
            <div className="flex justify-between items-center mb-1">
              <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Server Status</span>
              <div className={`w-2 h-2 rounded-full ${
                serverStatus === 'connected' ? 'bg-emerald-500 shadow-sm shadow-emerald-500/50' : 
                serverStatus === 'syncing' ? 'bg-blue-500 animate-pulse' : 'bg-red-500'
              }`}></div>
            </div>
            <div className="text-[10px] text-slate-400 font-bold uppercase">
              {serverStatus === 'connected' ? 'Połączony' : serverStatus === 'syncing' ? 'Synchronizacja' : 'Offline'}
            </div>
          </div>

          <div className="pt-6 border-t border-slate-800">
             <button onClick={handleLogout} className="w-full flex items-center space-x-3 px-4 py-3 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-xl transition-all group">
               <LogOutIcon className="group-hover:-translate-x-1 transition-transform" />
               <span className="font-black text-xs uppercase tracking-widest">Wyloguj</span>
             </button>
          </div>
        </div>
      </nav>

      {/* Mobile Top Bar */}
      <div className="md:hidden bg-white/90 backdrop-blur-lg border-b border-slate-100 px-5 py-4 flex items-center justify-between sticky top-0 z-50 shadow-sm">
         <div className="flex items-center space-x-3">
           <LogoIcon customUrl={currentUser.customLogoUrl} className="text-blue-600" size={32} />
           <span className="font-black text-lg tracking-tighter text-slate-900">BP</span>
         </div>
         <h1 className="text-xs font-black text-slate-900 uppercase tracking-[0.2em]">{getPageTitle()}</h1>
         <div className="flex items-center space-x-3">
            <div className={`w-2 h-2 rounded-full ${serverStatus === 'connected' ? 'bg-emerald-500' : 'bg-red-500'}`}></div>
         </div>
      </div>

      <main className="flex-1 flex flex-col min-w-0 relative">
        {/* Desktop Top Header */}
        <header className="hidden md:flex bg-white/80 backdrop-blur-md border-b border-slate-100 h-20 items-center justify-between px-10 sticky top-0 z-10">
          <div className="flex items-center space-x-6">
             <div>
              <h1 className="text-lg font-black text-slate-900 leading-none tracking-tight">{getPageTitle()}</h1>
              <h2 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Użytkownik: {currentUser.name}</h2>
            </div>
          </div>
          <div className="flex items-center space-x-4">
             {serverStatus === 'syncing' && (
               <div className="flex items-center space-x-2 bg-blue-50 px-3 py-1.5 rounded-full animate-in fade-in zoom-in duration-300">
                 <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-ping"></div>
                 <span className="text-[9px] font-black text-blue-600 uppercase tracking-widest">Przesyłanie na serwer</span>
               </div>
             )}
          </div>
        </header>

        <div className="flex-1 p-4 md:p-10 overflow-y-auto">
          <div className="max-w-7xl mx-auto pb-24 md:pb-0">
            <div 
              key={activeTab} 
              className="animate-in fade-in slide-in-from-right-6 md:slide-in-from-bottom-4 duration-500 ease-out fill-mode-both"
            >
              {activeTab === 'dashboard' && <Dashboard projects={projects} categories={categories} costs={costs} setCosts={setCosts} />}
              {activeTab === 'projects' && <ProjectList projects={projects} setProjects={setProjects} costs={costs} setCosts={setCosts} categories={categories} />}
              {activeTab === 'costs' && <CostTracker projects={projects} categories={categories} costs={costs} setCosts={setCosts} />}
              {activeTab === 'settings' && (
                <Settings 
                  projects={projects} costs={costs} categories={categories} 
                  setCategories={setCategories} setProjects={setProjects} setCosts={setCosts}
                  currentUser={currentUser} setCurrentUser={setCurrentUser} syncStatus={syncStatus}
                  googleAccessToken={googleAccessToken} setGoogleAccessToken={setGoogleAccessToken}
                />
              )}
            </div>
          </div>
        </div>
      </main>

      {/* Premium Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-2xl border-t border-slate-100 flex justify-around p-2 pb-8 z-50 shadow-[0_-10px_40px_rgba(0,0,0,0.04)]">
        <MobileNavItem active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} icon={<DashboardIcon />} label="Home" />
        <MobileNavItem active={activeTab === 'projects'} onClick={() => setActiveTab('projects')} icon={<LayersIcon />} label="Projekty" />
        <MobileNavItem active={activeTab === 'costs'} onClick={() => setActiveTab('costs')} icon={<ReceiptIcon />} label="Koszty" />
        <MobileNavItem active={activeTab === 'settings'} onClick={() => setActiveTab('settings')} icon={<SettingsIcon />} label="Opcje" />
      </nav>
    </div>
  );
};

const NavItem: React.FC<{ active: boolean; onClick: () => void; icon: React.ReactNode; label: string }> = ({ active, onClick, icon, label }) => (
  <button
    onClick={onClick}
    className={`flex items-center space-x-4 px-5 py-3.5 rounded-2xl transition-all duration-300 group ${
      active ? 'bg-blue-600 text-white shadow-xl shadow-blue-500/20 translate-x-1 font-bold' : 'text-slate-400 hover:bg-slate-800 hover:text-slate-100 hover:translate-x-1'
    }`}
  >
    <div className={`transition-colors duration-300 ${active ? 'text-white' : 'text-slate-600 group-hover:text-slate-300'}`}>
      {icon}
    </div>
    <span className="text-sm">{label}</span>
  </button>
);

const MobileNavItem: React.FC<{ active: boolean; onClick: () => void; icon: React.ReactNode; label: string }> = ({ active, onClick, icon, label }) => (
  <button
    onClick={onClick}
    className={`flex flex-col items-center justify-center flex-1 py-1 px-1 transition-all duration-500 relative ${
      active ? 'text-blue-600' : 'text-slate-400'
    }`}
  >
    <div className={`transition-all duration-300 transform ${active ? 'scale-110 -translate-y-1' : 'scale-100 opacity-60'}`}>
      {React.cloneElement(icon as React.ReactElement<any>, { size: 22 })}
    </div>
    <span className={`text-[8px] font-black uppercase tracking-[0.2em] mt-2 transition-all duration-300 ${active ? 'opacity-100' : 'opacity-40'}`}>
      {label}
    </span>
    {active && (
      <div className="absolute -bottom-1 w-1.5 h-1.5 bg-blue-600 rounded-full animate-in zoom-in fade-in duration-500"></div>
    )}
  </button>
);

const App: React.FC = () => {
  return (
    <ToastProvider>
      <AppContent />
    </ToastProvider>
  );
};

export default App;
